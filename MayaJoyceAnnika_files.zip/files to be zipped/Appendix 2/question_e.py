import numpy as np
import matplotlib.pyplot as plt

import math 
import os
os.chdir('/Users/mayamilrod/Desktop/cis265/project/files')


def gnn_freq(file_name):

    file = open(file_name, 'r')

    nucleotides = ['A', 'G', 'T', 'C']

    gnn = []

    codon_dict = {}

    codons = []

    gnn_count = 0

    codon_count = 0

    for i in nucleotides:
        for x in nucleotides:
            gnn += ['G' + i + x]

    for nt1 in nucleotides:
        for nt2 in nucleotides:
            for nt3 in nucleotides:
               codons += [nt1 + nt2 + nt3]

    for n in codons:
        codon_dict[n] = 0

    for line in file:
        for n in range(0,len(line)-3,3):
            codon_dict[line[n:n+3]] += 1

    for nuc in gnn:
        gnn_count += codon_dict[nuc]

    for nuc in codons:
        codon_count += codon_dict[nuc]

    gnn_freq = round((gnn_count/codon_count)*100, 2)

    file.close()

    #print('gnn codon frequency: ', gnn_freq, '%')

    return gnn_freq
        
print(gnn_freq('1069nt_orf_top10.txt'))

def g_freq(file_name):

    file = open(file_name, 'r')

    nuc_count = 0

    g_count = 0

    for line in file:
        for i in line:
            nuc_count += 1
            if i == 'G':
                g_count += 1


    g_freq = round((g_count/nuc_count)*100, 2)

    file.close()

    #print(g_count, nuc_count)

    #print('g nucleotide frequency: ', g_freq, '%')

    return g_freq

print(g_freq('1069nt_orf_top10.txt'))

def bar_chart_comparison(filename1, filename2, filename3):

    file1 = open(filename1, 'r')
    file2 = open(filename2, 'r')
    file3 = open(filename3, 'r')

    barWidth = 0.10
    fig = plt.subplots(figsize =(12, 8))

    g = [g_freq(filename1), g_freq(filename2), g_freq(filename3)]
    gnn = [gnn_freq(filename1), gnn_freq(filename2), gnn_freq(filename3)]

    br1 = np.arange(len(g))
    br2 = [x + barWidth for x in br1]
 
    plt.bar(br1, g, color ='deeppink', width = barWidth,
            edgecolor ='grey', label ='g')
    plt.bar(br2, gnn, color ='springgreen', width = barWidth,
            edgecolor ='grey', label ='gnn')

    plt.xlabel('Protein Expression', fontweight ='bold', fontsize = 15)
    plt.ylabel('Frequency (%)', fontweight ='bold', fontsize = 15)
    plt.xticks([r + barWidth for r in range(len(g))],
            ['top 10%', 'middle 10%', 'bottom 10%'])


    plt.legend()
    plt.title('GNN Codon Frequency vs G Nucleotide Frequency for Yeast ORFs')
    return plt.show()
    file1.close()
    file2.close
    file3.close()

print(bar_chart_comparison('1069nt_orf_top10.txt', '1069nt_orf_mid10.txt', '1069nt_orf_bottom10.txt'))


