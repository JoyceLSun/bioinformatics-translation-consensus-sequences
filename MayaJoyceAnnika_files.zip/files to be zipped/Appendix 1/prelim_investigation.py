import numpy as np
import matplotlib.pyplot as plt

import math 
import os
os.chdir('/Users/mayamilrod/Desktop/cis265/project/files')

def weight_at_position(file_name, position):
    '''
    takes file name, position (int) -> dict{}
    traverses all bases at position indicated,
    returns dictionary of weighted scores for each base
    
    '''
    file = open(file_name, 'r')

    A = 0
    G = 0
    C = 0
    T = 0

    w_A = 0
    w_G = 0
    w_C = 0
    w_T = 0

    '''weight_dict = {0:{'A':0, 'G':0, 'C':0, 'T':0}, 1:{'A':0, 'G':0, 'C':0, 'T':0},
                   2:{'A':0, 'G':0, 'C':0, 'T':0}, 3:{'A':0, 'G':0, 'C':0, 'T':0},
                   4:{'A':0, 'G':0, 'C':0, 'T':0}, 5:{'A':0, 'G':0, 'C':0, 'T':0},
                   6:{'A':0, 'G':0, 'C':0, 'T':0}, 7:{'A':0, 'G':0, 'C':0, 'T':0},
                   8:{'A':0, 'G':0, 'C':0, 'T':0}, 9:{'A':0, 'G':0, 'C':0, 'T':0},
                   10:{'A':0, 'G':0, 'C':0, 'T':0}, 11:{'A':0, 'G':0, 'C':0, 'T':0},
                   12:{'A':0, 'G':0, 'C':0, 'T':0}, 13:{'A':0, 'G':0, 'C':0, 'T':0},
                   14:{'A':0, 'G':0, 'C':0, 'T':0}, 15:{'A':0, 'G':0, 'C':0, 'T':0},
                   16:{'A':0, 'G':0, 'C':0, 'T':0}, 17:{'A':0, 'G':0, 'C':0, 'T':0},
                   18:{'A':0, 'G':0, 'C':0, 'T':0}, 19:{'A':0, 'G':0, 'C':0, 'T':0}} '''

    nuc_dict = {'A':0, 'G':0, 'C':0, 'T':0}
    '''
    tabs which bases are in the same position of different gene seqs. 
    '''
    for line in file:
        if line[position] == 'A':
            A += 1
        if line[position] == 'G':
            G += 1
        if line[position] == 'C':
            C += 1
        if line[position] == 'T':
            T += 1

    total = A + G + C + T
        
    w_A = A/total
    w_G = G/total
    w_C = C/total
    w_T = T/total


    if w_A == 0:
        nuc_dict['A'] = w_A
    else:
        nuc_dict['A'] = math.log2(w_A) + 2
                
    if w_G == 0:
        nuc_dict['G'] = w_G
    else:
        nuc_dict['G'] = math.log2(w_G) + 2

    if w_C == 0:
        nuc_dict['C'] = w_C
    else:
        nuc_dict['C'] = math.log2(w_C) + 2

    if w_T == 0:
        nuc_dict['T'] = w_T
    else:
        nuc_dict['T'] = math.log2(w_T) + 2


    file.close()

    return nuc_dict

#print(weight_at_position('top10%_nogene.txt', 15))

def total_weights(file_name):
    '''
    file->nested dict{}
    takes a file and runs weight_at_position for each nucleotide position
    outputs a nested dict of the weight scores of nucleotides at each position
    for the genes in the file indicated
    '''

    file = open(file_name, 'r')
    
    total_dict = {}
    
    x = int(input('input sequence length: '))
    
    for i in range(0,x-1):
        total_dict[i] = weight_at_position(file_name,i)
    return total_dict

    #print(total_dict)
    return total_dict

#print(total_weights('top10%_nogene.txt'))
    

#print(total_weights('test.txt'))

def information_by_line(file_name):
    '''
    file->dict
    using weight matrices calculated from weight_at_position within
    total_weights for each line
    '''
    file = open(file_name, 'r')
    total_dict = total_weights(file_name)
    info_score_dict = {}
    #info_score = 0
    line_num=0
    #i=0
    #file_length=len(file.readlines())
    #f=0
    for line in file:
        info_score=0
        for i in range(0,len(line)):
            if line[i] == 'A':
                info_score += total_dict[i]['A']
                #i+=1
            if line[i] == 'G':
                info_score += total_dict[i]['G']
                #i+=1
            if line[i] == 'C':
                info_score += total_dict[i]['C']
                #i+=1
            if line[i] == 'T':
                info_score += total_dict[i]['T']
                #i+=1
        info_score_dict[line_num] = round(info_score, 2)

        line_num += 1
        #print (line_num)
    file.close()
    #print('information in each sequence: ', info_score_dict)
    return info_score_dict
    

#print(information_by_line('top10%_nogene.txt'))

def information_of_aligned_sequences(file_name):

    file = open(file_name, 'r')
    info_score_dict = information_by_line(file_name)
    total = 0

    for i in range(0,len(info_score_dict)):
        total += info_score_dict[i]

    avg_info = round(total/len(info_score_dict), 2)

    file.close()
    
    #print('information for alignment: ', avg_info)
    return avg_info

print(information_of_aligned_sequences('atg_info_bottom10.txt'))

def histogram_list(file_name):
    file = open(file_name, 'r')
    info_score_dict = information_by_line(file_name)

    list = []
    list2 = []

    for i in range(0, len(info_score_dict)):
        list += [info_score_dict[i]]

    for x in list:
        list2 += [int(x)]

    file.close()

    return list2
    
#print(histogram_list('test.txt'))


def make_histogram(file_name):

    file = open(file_name, 'r')
    x = histogram_list(file_name)
    name = input('name your histogram: ')



    plt.hist(x)
    plt.xlabel('Info Score', fontweight ='bold', fontsize = 15)
    plt.ylabel('Number of Genes', fontweight ='bold', fontsize = 15)
    plt.title(name)
    return plt.show()

    file.close()

print(make_histogram('bottom10%_nogene.txt'))

def information_bar_chart_comparison(filename1, filename2, filename3):

    file1 = open(filename1, 'r')
    file2 = open(filename2, 'r')
    file3 = open(filename3, 'r')

    barWidth = 0.10
    fig = plt.subplots(figsize =(12, 8))

    information = [information_of_aligned_sequences(filename1), information_of_aligned_sequences(filename2), information_of_aligned_sequences(filename3)]

    br1 = np.arange(len(information))
 
    plt.bar(br1, information, color ='deeppink', width = barWidth,
            edgecolor ='grey', label ='over all information of aligned sequences')

    plt.xlabel('Protein Expression', fontweight ='bold', fontsize = 15)
    plt.ylabel('Over All Information', fontweight ='bold', fontsize = 15)
    plt.xticks([r + barWidth for r in range(len(information))],
            ['top 10%', 'middle 10%', 'bottom 10%'])


    plt.legend()
    plt.title('Over All Information For Aligned Sequences of Different Protein Expression Groups')
    return plt.show()
    file1.close()
    file2.close
    file3.close()

#print(information_bar_chart_comparison('top10%_nogene.txt', 'middle10%_nogene.txt', 'bottom10%_nogene.txt'))








        
    
